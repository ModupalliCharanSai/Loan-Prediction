LOAN PREDICTION 

 Group Members:
Narayana Chakravarthi- BL.EN.U4CSE20113
Modupalli charan sai_BL.EN.U4CSE20101
M Preetham-BL.EN.U4CSE20097
 

In this Loan prediction The users will able to predict whether they able to get the loan from their requirments given to bank which are legible to them and bank.
The users will provide various data which are essential to get loan from desired bank for their desires.
The users will give their name, Loan amount, applicant income, co-applicant income, dependents,credit score etc..
The credit score will plays the crucial loan in getting dessired loan to applicant.
  
From the details of applicants we will predict loan elgibility and their status in the section of loan status.