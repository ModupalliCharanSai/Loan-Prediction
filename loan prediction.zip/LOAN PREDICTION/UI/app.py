import streamlit as st
from PIL import Image
import pickle


model = pickle.load(open('./Model/hello.pkl', 'rb'))

def run():
    image1 = Image.open('mll.png')
    image1 = image1.resize((166,150))
    st.image(image1,use_column_width=False)
    st.title("Bank Loan Prediction using Machine Learning")

  
  
    
    acc =int( st.number_input('Account number',min_value=1, max_value=1000000, value=1, step=1))
    account_no=str(acc)
    if(length(account_no)<=1):
        st.warning('Please enter your bank account  number')
        st.stop()
      

   
    fn = st.text_input('Full Name as per your bank details')

    gender_display = ('Male','Female')
    gender_otions = list(range(len(gender_display)))
    gender = st.selectbox("Gender",gender_options, format_func=lambda x: gender_display[x])

    martial_display = ('yes','no')
    martial_options = list(range(len(martial_display)))
    martial = st.selectbox("Marital Status", martial_options, format_func=lambda x: martial_display[x])

    
    dependents_display = ('None','One','Two','More than Two dependents')
    dependents_options = list(range(len(dependents_display)))
    dependents = st.selectbox("Dependents",  dependents_options, format_func=lambda x: dependents_display[x])

    education_display = ('Graduate',' Not Graduate')
    education_options = list(range(len(education_display)))
    education = st.selectbox("Education",education_options, format_func=lambda x: education_display[x])

    employment_display = ('Job','Business','none')
    employment_options = list(range(len(employment_display)))
    employment = st.selectbox("Employment Status",employment_options, format_func=lambda x: employment_display[x])

    property_display = ('urban','Semi-Urban','rural')
    property_options = list(range(len(property_display)))
    property = st.selectbox("Property Area",property_options, format_func=lambda x: property_display[x])

    
    credit_display = ('Between 400 to 500','Above 500-800',)
    credit_options = list(range(len(credit_display)))
    credit = st.selectbox("Credit Score",credit_options, format_func=lambda x: credit_display[x])

    monthly_income = st.number_input("Applicant's Monthly Income($)",value=0)

    co_monthly_income = st.number_input("Co-Applicant's Monthly Income($)",value=0)

    time_display = ['1 Month','6 Month','9Month','1 Year','18 Month']
    time_options = range(len(time_display))
    time = st.selectbox("Loan Duration",time_options, format_func=lambda x: time_display[x])

    loan_amount = st.number_input("Loan Amount",value=0)
    if(loan_amount)==0:
        st.warning('Please enter the loan amount correctly')
        st.stop()
        loan_amount = st.number_input("Loan Amount",value=0)

    if st.button("predict"):
        duration = 0
        if time == 0:
            k = 48
        if time == 1:
            k = 176
        if time == 2:
            k = 227
        if time == 3:
            k = 348
        if time == 4:
            k = 450
        attributes = [[gender, martial, dependents, education, employement, monthly_income, co_monthly_income, loan_amount, duration, credit, property]]
        prediction = model.predict(attributes)
        lc = [str(i) for i in prediction]
        ans = int("".join(lc))
        if ans == 0:
            st.error(
                "Hello: " + fn +" || "
                "Account number: "+account_no +' || '
                'According to bank Calculations, you will not get the loan from Bank'
            )
        else:
            st.success(
                "Hello: " + fn +" || "
                "Account number: "+account_no +' || '
                'Congratulations!! you will elgible to get the loan from Bank'
            )

run()